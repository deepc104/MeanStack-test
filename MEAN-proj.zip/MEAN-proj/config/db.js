module.exports = {
	url : 'mongodb://deep:deep@ds137040.mlab.com:37040/fbpagestats'
}