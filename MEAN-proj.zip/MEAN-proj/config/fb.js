module.exports = {
    client_id: '191096264723236',
	client_secret: 'd95f40775062e050e8ee6249c6f858cc'
}